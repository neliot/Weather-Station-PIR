############################################
# TITLE  # WEATHER APP
# AUTHOR # DR NEIL ELIOT
# DATE   # 08/01/2023
############################################
# NOTES
###################################################################################
# BEWARE ONLY USE THE INTERNAL DHT11 LIBRARY OR IT FREEZES
###################################################################################
# NE - 22/02/2023
# REMOVED BUZZER
###################################################################################

from machine import Pin
import ssd1306
from oled import Write, GFX, SSD1306_I2C
from oled.fonts import ubuntu_mono_12, ubuntu_mono_15, ubuntu_mono_20
from dht import DHT11
import framebuf
import time
import random

pir = Pin(18,Pin.IN,Pin.PULL_DOWN)
reset = Pin(15,Pin.OUT)
sensor = DHT11(Pin(7))
led = Pin(25,Pin.OUT)
i2c = machine.I2C(0,sda=Pin(16), scl=Pin(17), freq=400000)
oled = ssd1306.SSD1306_I2C(128, 64, i2c)
gfx = GFX(128, 64, oled.pixel)
write12 = Write(oled, ubuntu_mono_12)
write15 = Write(oled, ubuntu_mono_15)
write20 = Write(oled, ubuntu_mono_20)

# Raspberry Pi logo as 32x32 bytearray
buffer = bytearray(b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00|?\x00\x01\x86@\x80\x01\x01\x80\x80\x01\x11\x88\x80\x01\x05\xa0\x80\x00\x83\xc1\x00\x00C\xe3\x00\x00~\xfc\x00\x00L'\x00\x00\x9c\x11\x00\x00\xbf\xfd\x00\x00\xe1\x87\x00\x01\xc1\x83\x80\x02A\x82@\x02A\x82@\x02\xc1\xc2@\x02\xf6>\xc0\x01\xfc=\x80\x01\x18\x18\x80\x01\x88\x10\x80\x00\x8c!\x00\x00\x87\xf1\x00\x00\x7f\xf6\x00\x008\x1c\x00\x00\x0c \x00\x00\x03\xc0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00")

# Load the raspberry pi logo into the framebuffer (the image is 32x32)
fb = framebuf.FrameBuffer(buffer, 32, 32, framebuf.MONO_HLSB)

prevTemp = 0
prevHumi = 0

#def buzz():
#    buzzer.value(1)
#    time.sleep(0.05)
#    buzzer.value(0)

def arrowUp(x,y):
    gfx.triangle(10+x, 0+y, 0+x, 10+y, 20+x, 10+y, 1)

def arrowDown(x,y):
    gfx.triangle(0+x, 0+y, 20+x, 0+y, 10+x, 10+y, 1)

def noArrow(x,y):
    gfx.rect(0+x, 4+y, 20, 5, 1)

def saverScreen():
    oled.fill(0)                                                 # CLEAR SCREEN
    oled.blit(fb,random.randint(0, (128-32)) , random.randint(0, (64-32)))
    oled.show()                                                  # DISPLAY THE SCREEN
    time.sleep(0.5)

def readingScreen():
    global prevTemp, prevHumi
    sensor.measure()                                             # READ DATA
    oled.fill(0)                                                 # CLEAR SCREEN
    oled.text("Weather Station",2,4)                             # TITLE DISPLAY
    oled.rect(0,0,127,15,1)
    oled.rect(0,16,127,48,1)                                     # BOX READINGS
    oled.hline(0,39,127,1)                                       # BOX READINGS
    oled.vline(100,16,48,1)                                      # BOX MOVEMENT
    newTemp = sensor.temperature()                               # READ TEMP
    newHumi = sensor.humidity()                                  # READ HUMIDITY
    write20.text("TEMP:{}*C".format(newTemp),3,18)               # DISPLAY TEMP
    write20.text("HUMI:{}%".format(newHumi),3,41)                # DISPLAY HUMIDITY

    if newTemp > prevTemp:                                       # TEMPERATURE GOING UP
        arrowUp(103,22)
    elif newTemp < prevTemp:                                     # TEMPERATURE GOING DOWN
        arrowDown(103,22)
    else:                                                        # STATIC TEMPERATURE
        noArrow(103,22)
    
    if newHumi > prevHumi:                                       # HUMIDITY GOING UP
        arrowUp(103,44)
    elif newHumi < prevHumi:                                     # HUMIDITY GOING DOWN
        arrowDown(103,44)
    else:                                                        # STATIC HUMIDITY
        noArrow(103,44)
    prevTemp = newTemp                                           # STORE NEW TEMP
    prevHumi = newHumi                                           # STORE NEW HUMIDITY
    oled.show()                                                  # DISPLAY THE SCREEN
    time.sleep(2)
    
while True:
    led.toggle()
    if pir.value() == 0:
        saverScreen()
    else:
        readingScreen()
    if reset.value():                                            # RESET PICO
        machine.reset()        
                                               # PAUSE 2 SECONDS
